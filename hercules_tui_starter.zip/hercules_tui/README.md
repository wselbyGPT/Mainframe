# Hercules TK4- / MVS TUI starter

This is a starter Textual TUI that:

- launches Hercules as a subprocess
- tails Hercules console output
- connects to the TK4- 3270 console through `s3270`
- renders the current 3270 screen in a side pane
- sends basic panel and 3270 commands from one input bar

## Commands inside the TUI

- `/start` — start or stop Hercules
- `/connect` — connect `s3270` to `CONS@127.0.0.1:3270`
- `/h <cmd>` — send a Hercules panel command
- `/t <text>` — type text into the active 3270 field
- `/enter` — press Enter
- `/pf3` — press PF3
- `/clear` — send Clear

## Suggested host setup

Install Python deps:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Install a 3270 backend and Hercules on Ubuntu / WSL:

```bash
sudo apt update
sudo apt install c3270 x3270
```

Then ensure `s3270` and `hercules` are on your PATH.

Run:

```bash
python3 hercules_tui.py
```

## Notes

This is intentionally a practical v1. It does not implement the 3270 protocol itself; it uses `s3270` as a reliable backend and gives you your own dashboard and workflow on top.
