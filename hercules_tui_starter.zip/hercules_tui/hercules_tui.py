from __future__ import annotations

from dataclasses import dataclass
from queue import Empty, Queue
from subprocess import PIPE, STDOUT, Popen
from threading import Thread
from typing import Optional

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.reactive import reactive
from textual.widgets import Button, Footer, Header, Input, RichLog, Static


@dataclass
class HerculesConfig:
    hercules_bin: str = "hercules"
    hercules_conf: str = "conf/tk4-.cnf"
    host: str = "127.0.0.1"
    port_3270: int = 3270
    lu_name: str = "CONS"


class HerculesRunner:
    def __init__(self) -> None:
        self.proc: Optional[Popen[str]] = None
        self.queue: Queue[str] = Queue()

    @property
    def running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self, hercules_bin: str, hercules_conf: str) -> None:
        if self.running:
            return
        self.proc = Popen(
            [hercules_bin, "-f", hercules_conf],
            stdin=PIPE,
            stdout=PIPE,
            stderr=STDOUT,
            text=True,
            bufsize=1,
        )
        assert self.proc.stdout is not None
        Thread(target=self._pump_stdout, args=(self.proc.stdout,), daemon=True).start()

    def _pump_stdout(self, stream) -> None:
        for line in stream:
            self.queue.put(line.rstrip("\n"))

    def send(self, command: str) -> None:
        if not self.running or self.proc is None or self.proc.stdin is None:
            raise RuntimeError("Hercules is not running")
        self.proc.stdin.write(command.rstrip() + "\n")
        self.proc.stdin.flush()

    def stop(self) -> None:
        if self.running and self.proc and self.proc.stdin:
            try:
                self.proc.stdin.write("quit\n")
                self.proc.stdin.flush()
            except Exception:
                pass
            try:
                self.proc.terminate()
            except Exception:
                pass


class S3270Client:
    def __init__(self) -> None:
        self.proc: Optional[Popen[str]] = None

    @property
    def connected(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self, hostspec: str) -> None:
        if self.connected:
            return
        self.proc = Popen(
            ["s3270", hostspec],
            stdin=PIPE,
            stdout=PIPE,
            stderr=PIPE,
            text=True,
            bufsize=1,
        )
        self.command("Capabilities(errd)")

    def stop(self) -> None:
        if self.connected and self.proc:
            try:
                self.command("Quit()")
            except Exception:
                pass
            try:
                self.proc.terminate()
            except Exception:
                pass

    def command(self, action: str) -> list[str]:
        if not self.connected or self.proc is None or self.proc.stdin is None or self.proc.stdout is None:
            raise RuntimeError("s3270 is not running")
        self.proc.stdin.write(action.rstrip() + "\n")
        self.proc.stdin.flush()

        lines: list[str] = []
        while True:
            raw = self.proc.stdout.readline()
            if raw == "":
                raise RuntimeError("s3270 terminated")
            line = raw.rstrip("\r\n")
            if line == "ok":
                return lines
            if line == "error":
                raise RuntimeError("\n".join(lines) if lines else f"s3270 action failed: {action}")
            if line.startswith("data: "):
                lines.append(line[6:])
            elif line.startswith("errd: "):
                lines.append(line[6:])
            else:
                # prompt/status line; ignore
                pass

    def ascii_screen(self) -> str:
        return "\n".join(self.command("Ascii()"))

    def send_text(self, text: str) -> None:
        escaped = text.replace("\\", "\\\\").replace('"', '\\"')
        self.command(f'String("{escaped}")')

    def enter(self) -> None:
        self.command("Enter")

    def clear(self) -> None:
        self.command("Clear")

    def pf(self, n: int) -> None:
        self.command(f"PF({n})")


class StatusBar(Static):
    status_text = reactive("Hercules: stopped | 3270: disconnected")

    def watch_status_text(self, value: str) -> None:
        self.update(value)


class HerculesTUI(App):
    CSS = """
    Screen {
        layout: vertical;
    }

    #topbar {
        height: auto;
        min-height: 1;
        padding: 0 1;
        border: round $accent;
    }

    #main {
        height: 1fr;
    }

    #left, #right {
        width: 1fr;
        height: 100%;
    }

    #cmdrow {
        height: auto;
    }

    .pane_title {
        height: auto;
        padding: 0 1;
    }

    #screen_view {
        padding: 0 1;
        overflow: auto auto;
    }

    Input {
        width: 1fr;
    }

    RichLog, #screen_view {
        border: round $accent;
    }
    """
    BINDINGS = [
        ("f5", "refresh_screen", "Refresh 3270"),
        ("f6", "connect_3270", "Connect 3270"),
        ("f7", "clear_logs", "Clear Logs"),
        ("f8", "start_stop", "Start/Stop"),
    ]

    def __init__(self, cfg: HerculesConfig | None = None) -> None:
        super().__init__()
        self.cfg = cfg or HerculesConfig()
        self.herc = HerculesRunner()
        self.term3270 = S3270Client()

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield StatusBar(id="topbar")
        with Horizontal(id="main"):
            with Vertical(id="left"):
                yield Static("Hercules console", classes="pane_title")
                yield RichLog(id="herc_log", wrap=True, highlight=True, markup=False)
            with Vertical(id="right"):
                yield Static("3270 screen", classes="pane_title")
                yield Static("", id="screen_view")
        with Horizontal(id="cmdrow"):
            yield Input(placeholder="/h <panel cmd> | /t <text> | /enter | /pf3 | /clear", id="cmd")
            yield Button("Start", id="start")
            yield Button("3270", id="connect")
            yield Button("Quit", id="quit")
        yield Footer()

    def on_mount(self) -> None:
        self.set_interval(0.15, self._drain_hercules_queue)
        self.set_interval(0.50, self._poll_3270_screen)
        self.call_after_refresh(self.query_one("#cmd", Input).focus)
        self._set_status()

    def _set_status(self) -> None:
        herc = "running" if self.herc.running else "stopped"
        term = "connected" if self.term3270.connected else "disconnected"
        self.query_one(StatusBar).status_text = f"Hercules: {herc} | 3270: {term}"

    def _drain_hercules_queue(self) -> None:
        log = self.query_one("#herc_log", RichLog)
        changed = False
        while True:
            try:
                line = self.herc.queue.get_nowait()
            except Empty:
                break
            else:
                log.write(line)
                changed = True
        if changed:
            self._set_status()

    def _poll_3270_screen(self) -> None:
        if not self.term3270.connected:
            return
        try:
            screen = self.term3270.ascii_screen()
        except Exception as exc:
            self.query_one("#screen_view", Static).update(f"[3270 error]\n{exc}")
            self.term3270.stop()
            self._set_status()
            return
        self.query_one("#screen_view", Static).update(screen or "<empty 3270 screen>")
        self._set_status()

    def action_refresh_screen(self) -> None:
        self._poll_3270_screen()

    def action_clear_logs(self) -> None:
        self.query_one("#herc_log", RichLog).clear()
        self.query_one("#screen_view", Static).update("")

    def action_connect_3270(self) -> None:
        if not self.term3270.connected:
            hostspec = f"{self.cfg.lu_name}@{self.cfg.host}:{self.cfg.port_3270}"
            try:
                self.term3270.start(hostspec)
            except Exception as exc:
                self.notify(f"3270 connect failed: {exc}", severity="error")
        self._poll_3270_screen()
        self._set_status()

    def action_start_stop(self) -> None:
        if self.herc.running:
            self.herc.stop()
            self.term3270.stop()
        else:
            try:
                self.herc.start(self.cfg.hercules_bin, self.cfg.hercules_conf)
            except FileNotFoundError:
                self.notify("Could not find hercules in PATH", severity="error")
            except Exception as exc:
                self.notify(f"Failed to start Hercules: {exc}", severity="error")
        self._set_status()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "start":
            self.action_start_stop()
        elif event.button.id == "connect":
            self.action_connect_3270()
        elif event.button.id == "quit":
            self.exit()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        value = event.value.strip()
        if not value:
            return
        cmd = self.query_one("#cmd", Input)
        try:
            if value.startswith("/h "):
                self.herc.send(value[3:].strip())
            elif value == "/enter":
                self.term3270.enter()
            elif value == "/clear":
                self.term3270.clear()
            elif value.startswith("/pf"):
                self.term3270.pf(int(value[3:]))
            elif value.startswith("/t "):
                self.term3270.send_text(value[3:])
            elif value == "/connect":
                self.action_connect_3270()
            elif value == "/start":
                self.action_start_stop()
            else:
                self.herc.send(value)
        except Exception as exc:
            self.notify(str(exc), severity="error")
        finally:
            cmd.value = ""
            self._poll_3270_screen()
            self._set_status()

    def on_unmount(self) -> None:
        self.term3270.stop()
        self.herc.stop()


if __name__ == "__main__":
    HerculesTUI().run()
